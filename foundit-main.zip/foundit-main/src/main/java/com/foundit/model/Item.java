package com.foundit.model;


public class Item {
    private int id;
    private String title;
    private String description;
    private String category;
    private String location;
    private String dateFound;
    private String status;
    private String reporterName;
    private String reporterPhone;
    private String claimedBy;
    private String claimedPhone;

    public Item() {}

    public Item(int id, String title, String description, String category,
                String location, String dateFound, String status,
                String reporterName, String reporterPhone, String claimedBy, String claimedPhone) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.category = category;
        this.location = location;
        this.dateFound = dateFound;
        this.status = status;
        this.reporterName = reporterName;
        this.reporterPhone = reporterPhone;
        this.claimedBy = claimedBy;
        this.claimedPhone = claimedPhone;
    }

    // Getters
    public int getId()           { return id; }
    public String getTitle()     { return title; }
    public String getDescription(){ return description; }
    public String getCategory()  { return category; }
    public String getLocation()  { return location; }
    public String getDateFound() { return dateFound; }
    public String getStatus()    { return status; }
    public String getReporterName() { return reporterName; }
    public String getReporterPhone(){ return reporterPhone; }
    public String getClaimedBy() { return claimedBy; }
    public String getClaimedPhone() { return claimedPhone; }

    // Setters
    public void setId(int id)                   { this.id = id; }
    public void setTitle(String title)           { this.title = title; }
    public void setDescription(String d)         { this.description = d; }
    public void setCategory(String category)     { this.category = category; }
    public void setLocation(String location)     { this.location = location; }
    public void setDateFound(String dateFound)   { this.dateFound = dateFound; }
    public void setStatus(String status)         { this.status = status; }
    public void setReporterName(String reporterName) { this.reporterName = reporterName; }
    public void setReporterPhone(String reporterPhone){ this.reporterPhone = reporterPhone; }
    public void setClaimedBy(String claimedBy)   { this.claimedBy = claimedBy; }
    public void setClaimedPhone(String claimedPhone) { this.claimedPhone = claimedPhone; }

    @Override
    public String toString() {
        return "[" + id + "] " + title + " (" + status + ")";
    }
}
