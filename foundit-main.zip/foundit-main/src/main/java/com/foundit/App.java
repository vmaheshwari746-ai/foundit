package com.foundit;

import com.foundit.db.DatabaseManager;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Objects;

public class App extends Application {

    private static Stage primaryStage;

    @Override
    public void start(Stage stage) throws IOException {
        primaryStage = stage;
        DatabaseManager.init();
        showLogin();
    }

    public static void showLogin() throws IOException {
        FXMLLoader loader = new FXMLLoader(App.class.getResource("/com/foundit/fxml/Login.fxml"));
        Scene scene = new Scene(loader.load(), 900, 600);
        scene.getStylesheets().add(Objects.requireNonNull(App.class.getResource("/com/foundit/styles/theme.css")).toExternalForm());
        primaryStage.setTitle("FoundIt – Lost & Found");
        primaryStage.setScene(scene);
        primaryStage.setResizable(false);
        primaryStage.show();
    }

    public static void showDashboard() throws IOException {
        FXMLLoader loader = new FXMLLoader(App.class.getResource("/com/foundit/fxml/Dashboard.fxml"));
        Scene scene = new Scene(loader.load(), 1100, 700);
        scene.getStylesheets().add(Objects.requireNonNull(App.class.getResource("/com/foundit/styles/theme.css")).toExternalForm());
        primaryStage.setTitle("FoundIt – Admin Dashboard");
        primaryStage.setScene(scene);
        primaryStage.setResizable(true);
        primaryStage.setMinWidth(900);
        primaryStage.setMinHeight(600);
        primaryStage.centerOnScreen();
    }

    public static void showSearch() throws IOException {
        FXMLLoader loader = new FXMLLoader(App.class.getResource("/com/foundit/fxml/Search.fxml"));
        Scene scene = new Scene(loader.load(), 900, 640);
        scene.getStylesheets().add(Objects.requireNonNull(App.class.getResource("/com/foundit/styles/theme.css")).toExternalForm());
        primaryStage.setTitle("FoundIt – Search & Verify Item");
        primaryStage.setScene(scene);
        primaryStage.centerOnScreen();
    }

    public static Stage getPrimaryStage() {
        return primaryStage;
    }
}
