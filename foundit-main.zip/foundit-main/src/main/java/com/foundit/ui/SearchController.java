package com.foundit.ui;

import com.foundit.App;
import com.foundit.db.ItemDAO;
import com.foundit.model.Item;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.GridPane;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

public class SearchController implements Initializable {

    @FXML private TextField searchField;
    @FXML private TableView<Item> resultsTable;
    @FXML private TableColumn<Item, Integer> colId;
    @FXML private TableColumn<Item, String> colTitle;
    @FXML private TableColumn<Item, String> colCategory;
    @FXML private TableColumn<Item, String> colDate;
    @FXML private TableColumn<Item, String> colStatus;
    @FXML private TextArea detailArea;
    @FXML private Label resultCountLabel;

    private ObservableList<Item> results = FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colTitle.setCellValueFactory(new PropertyValueFactory<>("title"));
        colCategory.setCellValueFactory(new PropertyValueFactory<>("category"));
        colDate.setCellValueFactory(new PropertyValueFactory<>("dateFound"));
        colStatus.setCellValueFactory(new PropertyValueFactory<>("status"));

        colStatus.setCellFactory(col -> new TableCell<>() {
            @Override
            protected void updateItem(String status, boolean empty) {
                super.updateItem(status, empty);
                if (empty || status == null) { setGraphic(null); setText(null); return; }
                Label chip = new Label(status);
                chip.getStyleClass().add("status-chip");
                chip.getStyleClass().add("Claimed".equals(status) ? "status-claimed" : "status-available");
                setGraphic(chip);
                setText(null);
            }
        });

        resultsTable.setItems(results);
        resultsTable.setPlaceholder(new Label("Enter a keyword above and click Search."));

        resultsTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSel, newSel) -> {
            if (newSel != null) showDetail(newSel);
        });

        resultCountLabel.setText("");
    }

    @FXML
    private void handleSearch() {
        String keyword = searchField.getText().trim();
        if (keyword.isEmpty()) {
            results.setAll(ItemDAO.getAllItems());
        } else {
            results.setAll(ItemDAO.searchItems(keyword));
        }
        detailArea.clear();
        int count = results.size();
        resultCountLabel.setText(count == 0 ? "No items found." : count + " item(s) found.");
    }

    @FXML
    private void handleMarkClaimed() {
        Item selected = resultsTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert(Alert.AlertType.WARNING, "No Selection", "Please select an item first.");
            return;
        }
        if ("Claimed".equals(selected.getStatus())) {
            showAlert(Alert.AlertType.INFORMATION, "Already Claimed",
                    "This item was already claimed by: " + selected.getClaimedBy());
            return;
        }
        Optional<ClaimContact> result = showClaimDialog(selected);
        result.ifPresent(contact -> {
            if (!contact.name().isEmpty()) {
                ItemDAO.markAsClaimed(selected.getId(), contact.name(), contact.phone().isEmpty() ? null : contact.phone());
                handleSearch(); // refresh
            }
        });
    }

    @FXML
    private void handleBack() {
        try {
            App.showDashboard();
        } catch (IOException e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Failed to return to dashboard.");
        }
    }

    private void showDetail(Item item) {
        StringBuilder sb = new StringBuilder();
        sb.append("ID:          ").append(item.getId()).append("\n");
        sb.append("Title:       ").append(item.getTitle()).append("\n");
        sb.append("Category:    ").append(item.getCategory()).append("\n");
        sb.append("Location:    ").append(item.getLocation() != null ? item.getLocation() : "—").append("\n");
        sb.append("Date Found:  ").append(item.getDateFound()).append("\n");
        sb.append("Reported by: ").append(item.getReporterName() != null ? item.getReporterName() : "—").append("\n");
        sb.append("Reporter ph: ").append(item.getReporterPhone() != null ? item.getReporterPhone() : "—").append("\n");
        sb.append("Status:      ").append(item.getStatus()).append("\n");
        if (item.getClaimedBy() != null) {
            sb.append("Claimed by:  ").append(item.getClaimedBy()).append("\n");
            sb.append("Claimant ph: ").append(item.getClaimedPhone() != null ? item.getClaimedPhone() : "—").append("\n");
        }
        sb.append("\nDescription:\n").append(item.getDescription() != null ? item.getDescription() : "No description provided.");
        detailArea.setText(sb.toString());
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type, content);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.initOwner(App.getPrimaryStage());
        alert.showAndWait();
    }

    private Optional<ClaimContact> showClaimDialog(Item item) {
        Dialog<ClaimContact> dialog = new Dialog<>();
        dialog.setTitle("Mark as Claimed");
        dialog.setHeaderText("Item: " + item.getTitle());
        dialog.initOwner(App.getPrimaryStage());

        ButtonType saveButtonType = new ButtonType("Save Claim", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);
        dialog.getDialogPane().getStylesheets().add(App.class.getResource("/com/foundit/styles/theme.css").toExternalForm());

        TextField nameField = new TextField();
        nameField.setPromptText("Person who claimed it");
        nameField.getStyleClass().add("text-field-custom");

        TextField phoneField = new TextField();
        phoneField.setPromptText("Claimant phone number");
        phoneField.getStyleClass().add("text-field-custom");

        GridPane grid = new GridPane();
        grid.setHgap(12);
        grid.setVgap(12);
        grid.add(new Label("Claimed By *"), 0, 0);
        grid.add(nameField, 1, 0);
        grid.add(new Label("Phone Number"), 0, 1);
        grid.add(phoneField, 1, 1);
        dialog.getDialogPane().setContent(grid);

        dialog.setResultConverter(button -> {
            if (button == saveButtonType) {
                return new ClaimContact(nameField.getText().trim(), phoneField.getText().trim());
            }
            return null;
        });

        return dialog.showAndWait().filter(contact -> !contact.name().isEmpty());
    }

    private record ClaimContact(String name, String phone) {}
}
