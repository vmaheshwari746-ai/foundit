package com.foundit.ui;

import com.foundit.App;
import com.foundit.auth.AuthManager;
import com.foundit.db.ItemDAO;
import com.foundit.model.Item;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.GridPane;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

public class DashboardController implements Initializable {

    @FXML private TableView<Item> itemsTable;
    @FXML private TableColumn<Item, Integer> colId;
    @FXML private TableColumn<Item, String> colTitle;
    @FXML private TableColumn<Item, String> colCategory;
    @FXML private TableColumn<Item, String> colLocation;
    @FXML private TableColumn<Item, String> colDate;
    @FXML private TableColumn<Item, String> colStatus;
    @FXML private TextField searchField;
    @FXML private Label totalLabel;
    @FXML private Label availableLabel;
    @FXML private Label claimedLabel;

    private ObservableList<Item> masterData = FXCollections.observableArrayList();
    private FilteredList<Item> filteredData;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colTitle.setCellValueFactory(new PropertyValueFactory<>("title"));
        colCategory.setCellValueFactory(new PropertyValueFactory<>("category"));
        colLocation.setCellValueFactory(new PropertyValueFactory<>("location"));
        colDate.setCellValueFactory(new PropertyValueFactory<>("dateFound"));
        colStatus.setCellValueFactory(new PropertyValueFactory<>("status"));

        // Style status column
        colStatus.setCellFactory(col -> new TableCell<>() {
            @Override
            protected void updateItem(String status, boolean empty) {
                super.updateItem(status, empty);
                if (empty || status == null) {
                    setText(null);
                    setGraphic(null);
                    getStyleClass().removeAll("status-available", "status-claimed");
                } else {
                    Label chip = new Label(status);
                    chip.getStyleClass().add("status-chip");
                    if ("Claimed".equals(status)) {
                        chip.getStyleClass().add("status-claimed");
                    } else {
                        chip.getStyleClass().add("status-available");
                    }
                    setGraphic(chip);
                    setText(null);
                }
            }
        });

        filteredData = new FilteredList<>(masterData, p -> true);
        searchField.textProperty().addListener((obs, oldVal, newVal) -> {
            filteredData.setPredicate(item -> {
                if (newVal == null || newVal.isEmpty()) return true;
                String lower = newVal.toLowerCase();
                return item.getTitle().toLowerCase().contains(lower)
                        || (item.getDescription() != null && item.getDescription().toLowerCase().contains(lower))
                        || (item.getCategory() != null && item.getCategory().toLowerCase().contains(lower))
                        || (item.getLocation() != null && item.getLocation().toLowerCase().contains(lower))
                        || (item.getReporterName() != null && item.getReporterName().toLowerCase().contains(lower))
                        || (item.getReporterPhone() != null && item.getReporterPhone().toLowerCase().contains(lower))
                        || (item.getClaimedBy() != null && item.getClaimedBy().toLowerCase().contains(lower))
                        || (item.getClaimedPhone() != null && item.getClaimedPhone().toLowerCase().contains(lower));
            });
        });

        itemsTable.setItems(filteredData);
        itemsTable.setPlaceholder(new Label("No items found. Click 'Add New Item' to get started."));
        loadItems();
    }

    private void loadItems() {
        masterData.setAll(ItemDAO.getAllItems());
        updateStats();
    }

    private void updateStats() {
        long total = masterData.size();
        long claimed = masterData.stream().filter(i -> "Claimed".equals(i.getStatus())).count();
        long available = total - claimed;
        totalLabel.setText(String.valueOf(total));
        availableLabel.setText(String.valueOf(available));
        claimedLabel.setText(String.valueOf(claimed));
    }

    @FXML
    private void handleAddItem() {
        try {
            FXMLLoader loader = new FXMLLoader(App.class.getResource("/com/foundit/fxml/AddItem.fxml"));
            javafx.scene.Parent root = loader.load();
            javafx.stage.Stage dialog = new javafx.stage.Stage();
            dialog.setTitle("Report Found Item");
            dialog.initOwner(App.getPrimaryStage());
            dialog.initModality(javafx.stage.Modality.WINDOW_MODAL);
            javafx.scene.Scene scene = new javafx.scene.Scene(root, 500, 620);
            scene.getStylesheets().add(App.class.getResource("/com/foundit/styles/theme.css").toExternalForm());
            dialog.setScene(scene);
            dialog.setResizable(false);
            dialog.showAndWait();
            loadItems();
        } catch (IOException e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Could not open Add Item form.");
        }
    }

    @FXML
    private void handleSearch() {
        try {
            App.showSearch();
        } catch (IOException e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Could not open Search screen.");
        }
    }

    @FXML
    private void handleMarkClaimed() {
        Item selected = itemsTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert(Alert.AlertType.WARNING, "No Selection", "Please select an item from the table.");
            return;
        }
        if ("Claimed".equals(selected.getStatus())) {
            showAlert(Alert.AlertType.INFORMATION, "Already Claimed", "This item has already been claimed by: " + selected.getClaimedBy());
            return;
        }

        Optional<ClaimContact> result = showClaimDialog(selected);
        result.ifPresent(contact -> {
            if (!contact.name().isEmpty()) {
                ItemDAO.markAsClaimed(selected.getId(), contact.name(), contact.phone().isEmpty() ? null : contact.phone());
                loadItems();
            }
        });
    }

    @FXML
    private void handleMarkAvailable() {
        Item selected = itemsTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert(Alert.AlertType.WARNING, "No Selection", "Please select an item from the table.");
            return;
        }
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
                "Mark '" + selected.getTitle() + "' as Available again?",
                ButtonType.YES, ButtonType.NO);
        confirm.setTitle("Confirm");
        confirm.initOwner(App.getPrimaryStage());
        Optional<ButtonType> result = confirm.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.YES) {
            ItemDAO.markAsAvailable(selected.getId());
            loadItems();
        }
    }

    @FXML
    private void handleDeleteItem() {
        Item selected = itemsTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert(Alert.AlertType.WARNING, "No Selection", "Please select an item to delete.");
            return;
        }
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
                "Delete item '" + selected.getTitle() + "'? This cannot be undone.",
                ButtonType.YES, ButtonType.NO);
        confirm.setTitle("Confirm Delete");
        confirm.initOwner(App.getPrimaryStage());
        Optional<ButtonType> result = confirm.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.YES) {
            ItemDAO.deleteItem(selected.getId());
            loadItems();
        }
    }

    @FXML
    private void handleLogout() {
        AuthManager.logout();
        try {
            App.showLogin();
        } catch (IOException e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Failed to return to login screen.");
        }
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type, content);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.initOwner(App.getPrimaryStage());
        alert.showAndWait();
    }

    private Optional<ClaimContact> showClaimDialog(Item item) {
        Dialog<ClaimContact> dialog = new Dialog<>();
        dialog.setTitle("Mark as Claimed");
        dialog.setHeaderText("Item: " + item.getTitle());
        dialog.initOwner(App.getPrimaryStage());

        ButtonType saveButtonType = new ButtonType("Save Claim", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);
        dialog.getDialogPane().getStylesheets().add(App.class.getResource("/com/foundit/styles/theme.css").toExternalForm());

        TextField nameField = new TextField();
        nameField.setPromptText("Person who claimed it");
        nameField.getStyleClass().add("text-field-custom");

        TextField phoneField = new TextField();
        phoneField.setPromptText("Claimant phone number");
        phoneField.getStyleClass().add("text-field-custom");

        GridPane grid = new GridPane();
        grid.setHgap(12);
        grid.setVgap(12);
        grid.add(new Label("Claimed By *"), 0, 0);
        grid.add(nameField, 1, 0);
        grid.add(new Label("Phone Number"), 0, 1);
        grid.add(phoneField, 1, 1);
        dialog.getDialogPane().setContent(grid);

        dialog.setResultConverter(button -> {
            if (button == saveButtonType) {
                return new ClaimContact(nameField.getText().trim(), phoneField.getText().trim());
            }
            return null;
        });

        return dialog.showAndWait().filter(contact -> !contact.name().isEmpty());
    }

    private record ClaimContact(String name, String phone) {}
}
