package com.foundit.ui;

import com.foundit.db.ItemDAO;
import com.foundit.model.Item;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class AddItemController implements Initializable {

    @FXML private TextField titleField;
    @FXML private TextArea descriptionArea;
    @FXML private ComboBox<String> categoryCombo;
    @FXML private TextField locationField;
    @FXML private TextField reporterNameField;
    @FXML private TextField reporterPhoneField;
    @FXML private DatePicker datePicker;
    @FXML private Label errorLabel;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        categoryCombo.getItems().addAll(
                "Electronics", "Jewelry", "ID / Card", "Clothing",
                "Keys", "Bag / Wallet", "Books / Stationery", "Other"
        );
        categoryCombo.setValue("Electronics");
        datePicker.setValue(LocalDate.now());
        errorLabel.setVisible(false);
    }

    @FXML
    private void handleSave() {
        String title = titleField.getText().trim();
        String description = descriptionArea.getText().trim();
        String category = categoryCombo.getValue();
        String location = locationField.getText().trim();
        String reporterName = reporterNameField.getText().trim();
        String reporterPhone = reporterPhoneField.getText().trim();
        LocalDate date = datePicker.getValue();

        if (title.isEmpty()) {
            showError("Item title is required.");
            return;
        }
        if (date == null) {
            showError("Please select the date the item was found.");
            return;
        }

        Item item = new Item();
        item.setTitle(title);
        item.setDescription(description.isEmpty() ? null : description);
        item.setCategory(category);
        item.setLocation(location.isEmpty() ? null : location);
        item.setReporterName(reporterName.isEmpty() ? null : reporterName);
        item.setReporterPhone(reporterPhone.isEmpty() ? null : reporterPhone);
        item.setDateFound(date.toString());

        ItemDAO.addItem(item);
        closeDialog();
    }

    @FXML
    private void handleCancel() {
        closeDialog();
    }

    private void closeDialog() {
        Stage stage = (Stage) titleField.getScene().getWindow();
        stage.close();
    }

    private void showError(String msg) {
        errorLabel.setText(msg);
        errorLabel.setVisible(true);
    }
}
