package com.foundit.ui;

import com.foundit.App;
import com.foundit.auth.AuthManager;
import javafx.animation.FadeTransition;
import javafx.animation.TranslateTransition;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.util.Duration;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class LoginController implements Initializable {

    @FXML private VBox loginCard;
    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private Label errorLabel;
    @FXML private Button loginButton;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        errorLabel.setVisible(false);
        // Entrance animation
        loginCard.setOpacity(0);
        loginCard.setTranslateY(30);
        FadeTransition ft = new FadeTransition(Duration.millis(600), loginCard);
        ft.setToValue(1.0);
        TranslateTransition tt = new TranslateTransition(Duration.millis(600), loginCard);
        tt.setToY(0);
        ft.play();
        tt.play();

        // Allow Enter key to trigger login
        passwordField.setOnAction(e -> handleLogin());
        usernameField.setOnAction(e -> passwordField.requestFocus());
    }

    @FXML
    private void handleLogin() {
        String username = usernameField.getText().trim();
        String password = passwordField.getText();

        if (username.isEmpty() || password.isEmpty()) {
            showError("Please enter username and password.");
            return;
        }

        if (AuthManager.login(username, password)) {
            try {
                App.showDashboard();
            } catch (IOException e) {
                showError("Failed to load dashboard.");
            }
        } else {
            showError("Invalid username or password.");
            passwordField.clear();
            shakeCard();
        }
    }

    private void showError(String msg) {
        errorLabel.setText(msg);
        errorLabel.setVisible(true);
    }

    private void shakeCard() {
        TranslateTransition shake = new TranslateTransition(Duration.millis(80), loginCard);
        shake.setByX(12);
        shake.setCycleCount(4);
        shake.setAutoReverse(true);
        shake.play();
    }
}
