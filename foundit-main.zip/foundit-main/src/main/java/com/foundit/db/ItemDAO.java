package com.foundit.db;

import com.foundit.model.Item;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ItemDAO {

    public static void addItem(Item item) {
        String sql = """
                INSERT INTO items (
                    title, description, category, location, date_found,
                    reporter_name, reporter_phone, status
                ) VALUES (?, ?, ?, ?, ?, ?, ?, 'Available')
                """;
        try (PreparedStatement pstmt = DatabaseManager.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, item.getTitle());
            pstmt.setString(2, item.getDescription());
            pstmt.setString(3, item.getCategory());
            pstmt.setString(4, item.getLocation());
            pstmt.setString(5, item.getDateFound());
            pstmt.setString(6, item.getReporterName());
            pstmt.setString(7, item.getReporterPhone());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Failed to add item: " + e.getMessage(), e);
        }
    }

    public static List<Item> getAllItems() {
        return queryItems("SELECT * FROM items ORDER BY id DESC", null);
    }

    public static List<Item> searchItems(String keyword) {
        String sql = """
                SELECT * FROM items
                WHERE LOWER(title) LIKE ?
                   OR LOWER(description) LIKE ?
                   OR LOWER(category) LIKE ?
                   OR LOWER(location) LIKE ?
                   OR LOWER(reporter_name) LIKE ?
                   OR LOWER(reporter_phone) LIKE ?
                   OR LOWER(claimed_by) LIKE ?
                   OR LOWER(claimed_phone) LIKE ?
                ORDER BY id DESC
                """;
        String k = "%" + keyword.toLowerCase() + "%";
        return queryItems(sql, new String[]{k, k, k, k, k, k, k, k});
    }

    public static List<Item> filterByStatus(String status) {
        String sql = "SELECT * FROM items WHERE status = ? ORDER BY id DESC";
        return queryItems(sql, new String[]{status});
    }

    public static void markAsClaimed(int id, String claimedBy, String claimedPhone) {
        String sql = "UPDATE items SET status = 'Claimed', claimed_by = ?, claimed_phone = ? WHERE id = ?";
        try (PreparedStatement pstmt = DatabaseManager.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, claimedBy);
            pstmt.setString(2, claimedPhone);
            pstmt.setInt(3, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Failed to mark item as claimed: " + e.getMessage(), e);
        }
    }

    public static void markAsAvailable(int id) {
        String sql = "UPDATE items SET status = 'Available', claimed_by = NULL, claimed_phone = NULL WHERE id = ?";
        try (PreparedStatement pstmt = DatabaseManager.getConnection().prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Failed to update item: " + e.getMessage(), e);
        }
    }

    public static void deleteItem(int id) {
        String sql = "DELETE FROM items WHERE id = ?";
        try (PreparedStatement pstmt = DatabaseManager.getConnection().prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Failed to delete item: " + e.getMessage(), e);
        }
    }

    private static List<Item> queryItems(String sql, String[] params) {
        List<Item> items = new ArrayList<>();
        try (PreparedStatement pstmt = DatabaseManager.getConnection().prepareStatement(sql)) {
            if (params != null) {
                for (int i = 0; i < params.length; i++) {
                    pstmt.setString(i + 1, params[i]);
                }
            }
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                items.add(new Item(
                        rs.getInt("id"),
                        rs.getString("title"),
                        rs.getString("description"),
                        rs.getString("category"),
                        rs.getString("location"),
                        rs.getString("date_found"),
                        rs.getString("status"),
                        rs.getString("reporter_name"),
                        rs.getString("reporter_phone"),
                        rs.getString("claimed_by"),
                        rs.getString("claimed_phone")
                ));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to query items: " + e.getMessage(), e);
        }
        return items;
    }
}
