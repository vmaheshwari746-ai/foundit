package com.foundit.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseManager {

    private static final String DB_URL = "jdbc:sqlite:foundit.db";
    private static Connection connection;

    public static void init() {
        try {
            connection = DriverManager.getConnection(DB_URL);
            createTables();
            System.out.println("Database initialized successfully.");
        } catch (SQLException e) {
            throw new RuntimeException("Failed to initialize database: " + e.getMessage(), e);
        }
    }

    private static void createTables() throws SQLException {
        String sql = """
                CREATE TABLE IF NOT EXISTS items (
                    id          INTEGER PRIMARY KEY AUTOINCREMENT,
                    title       TEXT NOT NULL,
                    description TEXT,
                    category    TEXT,
                    location    TEXT,
                    date_found  TEXT,
                    status      TEXT DEFAULT 'Available',
                    reporter_name  TEXT,
                    reporter_phone TEXT,
                    claimed_by     TEXT,
                    claimed_phone  TEXT
                );
                """;
        try (Statement stmt = connection.createStatement()) {
            stmt.execute(sql);
            addColumnIfMissing(stmt, "reporter_name", "TEXT");
            addColumnIfMissing(stmt, "reporter_phone", "TEXT");
            addColumnIfMissing(stmt, "claimed_phone", "TEXT");
        }
    }

    private static void addColumnIfMissing(Statement stmt, String columnName, String columnType) throws SQLException {
        try {
            stmt.execute("ALTER TABLE items ADD COLUMN " + columnName + " " + columnType);
        } catch (SQLException e) {
            if (!e.getMessage().toLowerCase().contains("duplicate column name")) {
                throw e;
            }
        }
    }

    public static Connection getConnection() {
        try {
            if (connection == null || connection.isClosed()) {
                connection = DriverManager.getConnection(DB_URL);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to get database connection: " + e.getMessage(), e);
        }
        return connection;
    }

    public static void close() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            System.err.println("Error closing database: " + e.getMessage());
        }
    }
}
